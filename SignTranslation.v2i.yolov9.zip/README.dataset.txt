# SignTranslation > 2024-11-19 2:03pm
https://universe.roboflow.com/alisultan-amankos/signtranslation

Provided by a Roboflow user
License: CC BY 4.0

